Readme.txt

To compile, just run javac with no extra options

$ javac Assignment1.java